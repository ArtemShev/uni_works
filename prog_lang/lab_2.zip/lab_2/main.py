from classes.file_service import FileService
new_file_system = FileService()


while True:
    command = input("\033[33m {}" .format('set - сохранить файл по ID\n get - выдача сохраненного файла\n del - удаление по ID\n change - изменение ID сохраненного файла\n few - получение нескольких файлов по ID\n backup - бэкап в тече7нии 24 ч\n reincarnate - восстановление по бэкапу\n любая клавиша - выход :\n '))
    if command == 'set':
        print("ваш id : ",new_file_system.set_file(input("Укажите имя файла:\n")))
    elif command == 'get':
        print(new_file_system.get_file(int(input("Укажите id файла:\n"))))
    elif command == 'del':
        print(new_file_system.del_file(int(input("Укажите ID файла:\n"))))
    elif command == 'change':
        print(new_file_system.change_dict(int(input("Укажите id файла:")),int(input("Укажите новый id файла:"))))
    elif command == 'few':
        print(new_file_system.get_few_files(input("Укажите ID файлов:\n")))
    elif command == 'backup':
        print(new_file_system.backup(), "бэкап выполнен")
    elif command == 'reincarnate':
        print(new_file_system.reincarnate(), "вы восстановились")
    else:
        print("\033[31m {}" .format("Вы вышли"))
        exit(0)


